const API =
    "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/";

const FALLBACK =
    "https://latest.currency-api.pages.dev/v1/";


const amountInput =
    document.getElementById("amount");

const fromCurrency =
    document.getElementById("fromCurrency");

const toCurrency =
    document.getElementById("toCurrency");

const convertBtn =
    document.getElementById("convertBtn");

const swapBtn =
    document.getElementById("swapBtn");

const resultText =
    document.getElementById("resultText");

const rateText =
    document.getElementById("rateText");

const statusText =
    document.getElementById("status");

const languageBtn =
    document.getElementById("languageBtn");

const languageMenu =
    document.getElementById("languageMenu");


let currencies = {};

let currentLanguage = "en";


/* TOP CURRENCIES */

const topCurrencies = [
    "usd",
    "eur",
    "gel",
    "try",
    "rub"
];


/* FLAGS */

const flags = {

    usd: "🇺🇸",
    eur: "🇪🇺",
    gel: "🇬🇪",
    try: "🇹🇷",
    rub: "🇷🇺",

    gbp: "🇬🇧",
    chf: "🇨🇭",

    jpy: "🇯🇵",
    cny: "🇨🇳",
    krw: "🇰🇷",

    inr: "🇮🇳",
    cad: "🇨🇦",
    aud: "🇦🇺",
    nzd: "🇳🇿",

    brl: "🇧🇷",
    mxn: "🇲🇽",
    ars: "🇦🇷",
    clp: "🇨🇱",
    cop: "🇨🇴",
    pen: "🇵🇪",

    pln: "🇵🇱",
    czk: "🇨🇿",
    huf: "🇭🇺",
    ron: "🇷🇴",
    bgn: "🇧🇬",
    rsd: "🇷🇸",
    isk: "🇮🇸",
    uah: "🇺🇦",

    nok: "🇳🇴",
    sek: "🇸🇪",
    dkk: "🇩🇰",

    aed: "🇦🇪",
    sar: "🇸🇦",
    qar: "🇶🇦",
    kwd: "🇰🇼",
    bhd: "🇧🇭",
    omr: "🇴🇲",
    ils: "🇮🇱",
    jod: "🇯🇴",

    thb: "🇹🇭",
    vnd: "🇻🇳",
    php: "🇵🇭",
    idr: "🇮🇩",
    myr: "🇲🇾",
    sgd: "🇸🇬",

    pkr: "🇵🇰",
    bdt: "🇧🇩",
    npr: "🇳🇵",
    lkr: "🇱🇰",

    kzt: "🇰🇿",
    uzs: "🇺🇿",
    kgs: "🇰🇬",
    tjs: "🇹🇯",

    zar: "🇿🇦",
    egp: "🇪🇬",
    mad: "🇲🇦",
    dzd: "🇩🇿",
    ngn: "🇳🇬",
    kes: "🇰🇪",
    ugx: "🇺🇬",
    tzs: "🇹🇿",
    ghs: "🇬🇭",

    xau: "🥇",
    xag: "🥈",

    btc: "₿",
    eth: "Ξ",
    usdt: "💵",
    usdc: "💵"
};


/* LANGUAGE */

const translations = {

    en: {

        title: "Currency",

        subtitle:
            "Exchange Converter",

        amount:
            "Amount",

        from:
            "From",

        to:
            "To",

        convert:
            "Convert",

        loading:
            "Loading exchange rates...",

        updating:
            "Updating exchange rate...",

        loaded:
            "Rate updated",

        failed:
            "Could not load exchange rate.",

        available:
            "currencies available",

        footer:
            "Powered by PELE PRODUCTION PP",

        placeholder:
            "Enter amount"
    },


    ru: {

        title: "Валюта",

        subtitle:
            "Конвертер валют",

        amount:
            "Сумма",

        from:
            "Из",

        to:
            "В",

        convert:
            "Конвертировать",

        loading:
            "Загрузка курсов...",

        updating:
            "Обновление курса...",

        loaded:
            "Курс обновлён",

        failed:
            "Не удалось загрузить курс.",

        available:
            "валют доступно",

        footer:
            "Powered by PELE PRODUCTION PP",

        placeholder:
            "Введите сумму"
    },


    geo: {

        title: "ვალუტა",

        subtitle:
            "ვალუტის კონვერტერი",

        amount:
            "რაოდენობა",

        from:
            "საიდან",

        to:
            "სად",

        convert:
            "კონვერტაცია",

        loading:
            "კურსების ჩატვირთვა...",

        updating:
            "კურსის განახლება...",

        loaded:
            "კურსი განახლებულია",

        failed:
            "კურსის ჩატვირთვა ვერ მოხერხდა.",

        available:
            "ვალუტა ხელმისაწვდომია",

        footer:
            "შექმნილია PELE PRODUCTION PP-ის მიერ",

        placeholder:
            "შეიყვანე თანხა"
    }
};


/* FLAG */

function getFlag(code) {

    return flags[
        code.toLowerCase()
    ] || "🌐";
}


/* FETCH */

async function fetchJSON(
    url,
    fallbackUrl
) {

    try {

        const response =
            await fetch(url);

        if (!response.ok) {
            throw new Error(
                "Primary API failed"
            );
        }

        return await response.json();

    } catch {

        const response =
            await fetch(fallbackUrl);

        if (!response.ok) {
            throw new Error(
                "Fallback API failed"
            );
        }

        return await response.json();
    }
}


/* LOAD CURRENCIES */

async function loadCurrencies() {

    try {

        statusText.textContent =
            translations[currentLanguage]
                .loading;


        currencies =
            await fetchJSON(

                API +
                "currencies.json",

                FALLBACK +
                "currencies.json"
            );


        populateCurrencies();


        fromCurrency.value =
            "usd";

        toCurrency.value =
            "gel";


        statusText.textContent =
            `${Object.keys(currencies).length} ${
                translations[currentLanguage]
                    .available
            }`;


        convert();

    } catch (error) {

        console.error(error);

        statusText.textContent =
            translations[currentLanguage]
                .failed;
    }
}


/* CREATE OPTION */

function createCurrencyOption(code) {

    const option =
        document.createElement("option");


    const name =
        currencies[code] ||
        code.toUpperCase();


    option.value =
        code;


    option.textContent =
        `${getFlag(code)} ${name} (${code.toUpperCase()})`;


    return option;
}


/* POPULATE */

function populateCurrencies() {

    fromCurrency.innerHTML = "";
    toCurrency.innerHTML = "";


    /* TOP */

    topCurrencies.forEach(
        code => {

            if (!currencies[code]) {
                return;
            }


            fromCurrency.appendChild(
                createCurrencyOption(code)
            );


            toCurrency.appendChild(
                createCurrencyOption(code)
            );
        }
    );


    /* ALL OTHER */

    const others =
        Object.keys(currencies)

            .filter(
                code =>
                    !topCurrencies.includes(code)
            )

            .sort(
                (a, b) =>
                    currencies[a]
                        .localeCompare(
                            currencies[b]
                        )
            );


    others.forEach(
        code => {

            fromCurrency.appendChild(
                createCurrencyOption(code)
            );


            toCurrency.appendChild(
                createCurrencyOption(code)
            );
        }
    );
}


/* GET RATES */

async function getRates(currency) {

    return await fetchJSON(

        API +
        `currencies/${currency}.json`,

        FALLBACK +
        `currencies/${currency}.json`
    );
}


/* CONVERT */

async function convert() {

    const amount =
        parseFloat(
            amountInput.value
        );


    const from =
        fromCurrency.value
            .toLowerCase();


    const to =
        toCurrency.value
            .toLowerCase();


    if (
        isNaN(amount) ||
        amount < 0
    ) {

        resultText.textContent =
            "Enter a valid amount";

        return;
    }


    if (from === to) {

        resultText.textContent =
            `${formatNumber(amount)} ${
                to.toUpperCase()
            }`;


        rateText.textContent =
            `1 ${from.toUpperCase()} = 1 ${to.toUpperCase()}`;

        return;
    }


    try {

        statusText.textContent =
            translations[currentLanguage]
                .updating;


        const data =
            await getRates(from);


        const rates =
            data[from];


        if (
            !rates ||
            rates[to] === undefined
        ) {

            throw new Error(
                "Currency not supported"
            );
        }


        const rate =
            rates[to];


        const result =
            amount * rate;


        resultText.textContent =
            `${formatNumber(result)} ${
                to.toUpperCase()
            }`;


        rateText.textContent =
            `1 ${from.toUpperCase()} = ${
                formatNumber(rate)
            } ${to.toUpperCase()}`;


        statusText.textContent =
            `${translations[currentLanguage].loaded} • ${
                data.date || "latest"
            }`;

    } catch (error) {

        console.error(error);

        resultText.textContent =
            "Conversion failed";


        statusText.textContent =
            translations[currentLanguage]
                .failed;
    }
}


/* NUMBER */

function formatNumber(number) {

    return new Intl.NumberFormat(
        "en-US",
        {
            maximumFractionDigits: 8
        }
    ).format(number);
}


/* LANGUAGE */

function setLanguage(lang) {

    currentLanguage =
        lang;


    const t =
        translations[lang];


    document.documentElement.lang =
        lang === "geo"
            ? "ka"
            : lang;


    document.getElementById(
        "title"
    ).textContent =
        t.title;


    document.getElementById(
        "subtitle"
    ).textContent =
        t.subtitle;


    document.getElementById(
        "amountLabel"
    ).textContent =
        t.amount;


    document.getElementById(
        "fromLabel"
    ).textContent =
        t.from;


    document.getElementById(
        "toLabel"
    ).textContent =
        t.to;


    convertBtn.textContent =
        t.convert;


    amountInput.placeholder =
        t.placeholder;


    document.getElementById(
        "footerText"
    ).textContent =
        t.footer;


    languageBtn.textContent =
        lang === "en"
            ? "EN ▾"
            : lang === "ru"
                ? "RU ▾"
                : "GEO ▾";


    convert();
}


/* LANGUAGE MENU */

languageBtn.addEventListener(
    "click",
    () => {

        languageMenu
            .classList
            .toggle("show");
    }
);


document
    .querySelectorAll(
        "#languageMenu button"
    )
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {

                setLanguage(
                    button.dataset.lang
                );

                languageMenu
                    .classList
                    .remove("show");
            }
        );
    });


document.addEventListener(
    "click",
    event => {

        if (
            !event.target.closest(
                ".language"
            )
        ) {

            languageMenu
                .classList
                .remove("show");
        }
    }
);


/* SWAP */

swapBtn.addEventListener(
    "click",
    () => {

        const oldFrom =
            fromCurrency.value;


        fromCurrency.value =
            toCurrency.value;


        toCurrency.value =
            oldFrom;


        convert();
    }
);


/* EVENTS */

convertBtn.addEventListener(
    "click",
    convert
);

amountInput.addEventListener(
    "input",
    convert
);

fromCurrency.addEventListener(
    "change",
    convert
);

toCurrency.addEventListener(
    "change",
    convert
);


/* START */

setLanguage("en");

loadCurrencies();